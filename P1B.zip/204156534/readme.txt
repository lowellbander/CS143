Akshay Bakshi, 104 160 782
Lowell Bander, 204 156 534

Combination of pair programming and dividing the work into modules, then linking
things together
